import { Component } from '@angular/core';

@Component({
  selector: 'app-character-form',
  standalone: true,
  imports: [],
  templateUrl: './character-form.component.html',
  styleUrl: './character-form.component.scss'
})
export class CharacterFormComponent {

}
