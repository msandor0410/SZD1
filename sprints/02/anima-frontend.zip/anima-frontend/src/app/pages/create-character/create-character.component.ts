import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CharacterService } from '../../services/character.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-character',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './create-character.component.html',
  styleUrls: ['./create-character.component.scss']
})
export class CreateCharacterComponent {

  model: any = {
    creatorId: Number(localStorage.getItem('user_id'))
  };

  constructor(
    private service: CharacterService,
    private router: Router
  ) {}

  save() {
    this.service.createCharacter(this.model)
      .subscribe({
        next: () => this.router.navigate(['/dashboard']),
        error: err => console.error(err)
      });
  }
}
