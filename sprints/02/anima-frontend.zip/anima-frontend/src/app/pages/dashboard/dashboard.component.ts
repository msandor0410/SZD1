import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { CharacterService } from '../../services/character.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
})
export class DashboardComponent implements OnInit {

  private auth = inject(AuthService);

  username: string = '';
  characters: any[] = [];
  userId!: number;

  constructor(
    private characterService: CharacterService,
    private router: Router
  ) {}

  ngOnInit() {
    const storedUsername = localStorage.getItem('username');
    if (storedUsername) this.username = storedUsername;

    this.userId = Number(localStorage.getItem('user_id'));

    this.characterService.getMyCharacters(this.userId)
      .subscribe(chars => this.characters = chars);
  }

  logout() {
    this.auth.logout();
  }

  goCreate() {
    this.router.navigate(['/create-character']);
  }

  view(id: number) {
    this.router.navigate(['/character', id]);
  }

  delete(id: number) {
    this.characterService.deleteCharacter(id).subscribe(() => {
      this.characters = this.characters.filter(c => c.characterId !== id);
    });
  }
}
