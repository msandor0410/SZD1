package hu.sandor.anima.animabackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnimaBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
