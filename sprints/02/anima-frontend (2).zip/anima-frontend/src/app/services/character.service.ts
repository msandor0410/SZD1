import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { FormsModule } from '@angular/forms';


@Injectable({
  providedIn: 'root'
})
export class CharacterService {

  private API = 'http://localhost:8080/api/characters';

  constructor(private http: HttpClient) {}

  private authHeader() {
    const token = localStorage.getItem('auth_token');
    return {
      headers: new HttpHeaders({
        'Authorization': `Bearer ${token}`
      })
    };
  }

  getMyCharacters(userId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.API}/creator/${userId}`, this.authHeader());
  }

  createCharacter(data: any): Observable<any> {
    return this.http.post(this.API, data, this.authHeader());
  }

  getCharacter(id: number): Observable<any> {
    return this.http.get(`${this.API}/${id}`, this.authHeader());
  }

  updateCharacter(id: number, data: any): Observable<any> {
    return this.http.put(`${this.API}/${id}`, data, this.authHeader());
  }

  deleteCharacter(id: number): Observable<any> {
    return this.http.delete(`${this.API}/${id}`, this.authHeader());
  }
}
